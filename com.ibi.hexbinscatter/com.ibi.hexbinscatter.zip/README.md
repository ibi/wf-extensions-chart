###### Marker Extension
Hexbin Scatter extension for WebFocus 8200.
