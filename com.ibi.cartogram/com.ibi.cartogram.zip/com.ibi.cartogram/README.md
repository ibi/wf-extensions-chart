# com.ibi.cartogram
WebFOCUS Plug In for USA Map as a Cartogram developed by Mario Delgado-Information Builders, Inc.
Implements Catogram as developed by Shawn Allen.  See: http://prag.ma/code/d3-cartogram/

CartogramPrototype.html is a simplified prototype of the technique on http://prag.ma/code/d3-cartogram/ with randomly generated numbers.
