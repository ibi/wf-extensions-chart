###### Liquid Gauge Extension
Liquid Gauge extension for WebFocus 8200.
Based on the d3 pluging by [Curtis Bratton](http://bl.ocks.org/brattonc/5e5ce9beee483220e2f6).
