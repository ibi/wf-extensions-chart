###### Marker Extension
Marker extension for WebFocus 8200.
