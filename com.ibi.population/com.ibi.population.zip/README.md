###### Population Pyramid Extension
Population Pyramid extension for WebFocus 8200
