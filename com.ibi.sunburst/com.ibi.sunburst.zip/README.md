###### Arc Extension
Sunburst extension for WebFocus 8200
