<<<<<<< HEAD
###### Sankey Flowchart Extension
Sankey Flowchart extension for WebFocus 8200.
Based on the [Sankey d3 pluging](https://github.com/d3/d3-plugins/tree/master/sankey).
=======
###### Sankey Flowchart Extension
Sankey Flowchart extension for WebFocus 8200.
Based on the [Sankey d3 pluging](https://github.com/d3/d3-plugins/tree/master/sankey).
>>>>>>> 0b7b0392532753a2fa907377e86c1639eae751cc
