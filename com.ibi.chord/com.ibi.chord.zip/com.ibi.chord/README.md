###### Interactive Chord Diagram Extension
Interactive chord diagram extension for WebFocus 8200.
Based on the chord d3 layout (https://github.com/mbostock/d3/wiki/Chord-Layout#chord).