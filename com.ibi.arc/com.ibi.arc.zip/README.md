###### Arc Extension
Arc extension for WebFocus 8200. Has three modes: regular, stacked and percent.
