#### Extension Template for WebFocus 8200

# Template Extension

This extension is not intended to be installed or used in WebFocus.  Instead, it serves as a template for creating new extensions.

To create a new extension, first make a copy of this template extension, rename the containing folder, the root .js file and the 'id' string in the root .js file's config block to match your extension's name.  Adjust the entries in properties.json. Turn on / off extension modules in the root .js file, then add code to draw the extension.

